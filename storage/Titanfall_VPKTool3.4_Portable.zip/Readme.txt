===========================================
===========================================
TITANFALL VPKTOOL
===========================================
===========================================

===========================
Library/Author Information:
===========================

Title:
TitanFall VPK Tool

Base Release Date:
Wednesday, 3 August 2014

Author:
Cra0kalo

Build:
3.4 Public Beta Release

Email:
me@cra0kalo.com (Cihan/Cra0kalo)

Website:
http://dev.cra0kalo.com


Written In:
.NET/C++